# USER SETUP - Note this script takes 5-15 minutes for multiple scattering corrections
cylinder_radius = 0.4 # Radius is in cm
cylinder_height = 4.0 # Height is in cm
cylinder_position = [0., 0., 0.]
geometry_json = {'Shape': 'Cylinder', 'Height': cylinder_height, 'Radius': cylinder_radius, 'Center': cylinder_position}
material_json = {'ChemicalFormula': 'V'}

# Essential files required : - 
# Offset file:
cal_file_path = r"C:\Users\ezz64382\Desktop\MultipleScattering\InvestigationUsingPOLARISdata\cycle_16_3_silicon_all_spectra.cal"
# Grouping file:
grouping_file_path = r"C:\Users\ezz64382\Desktop\MultipleScattering\InvestigationUsingPOLARISdata\Master_copy_of_grouping_file_with_essential_masks.cal"
#----------------------------------------------------------------------------------------------------------------------#

# Load vanadium and set the sample
Load(Filename= 'POL95598.nxs', OutputWorkspace='POL95598')
NormaliseByCurrent(InputWorkspace='POL95598', OutputWorkspace='POL95598')
SetSample(InputWorkspace='POL95598', Geometry=geometry_json, Material=material_json)
# Load background count
Load(Filename='POL95597.nxs', OutputWorkspace='POL95597')
NormaliseByCurrent(InputWorkspace='POL95597', OutputWorkspace='POL95597')
# subtract the background from the vanadium
Minus(LHSWorkspace='POL95598', RHSWorkspace='POL95597', OutputWorkspace='POL95598')
DeleteWorkspace('POL95597')
# get rid of 'negative' counts at very low TOF
CropWorkspace(InputWorkspace='POL95598', OutputWorkspace='POL95598', XMin=750, XMax=20000)
AlignDetectors(InputWorkspace='POL95598', OutputWorkspace='POL95598', CalibrationFile=cal_file_path)
# the first 55 detectors are unused detectors or monitors on Polaris
MaskDetectors(Workspace='POL95598', SpectraList='1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55')

# Multiple Scattering Cylinder Absorption correction
ConvertUnits(InputWorkspace='POL95598', OutputWorkspace='POL95598_MSCA', Target='Wavelength')
MultipleScatteringCylinderAbsorption(InputWorkspace='POL95598_MSCA', OutputWorkspace='POL95598_MSCA', CylinderSampleRadius=0.4)

# Mayers correction
ConvertUnits(InputWorkspace='POL95598', OutputWorkspace='POL95598_Mayers', Target='TOF')
MayersSampleCorrection(InputWorkspace='POL95598_Mayers', MultipleScattering=True, OutputWorkspace='POL95598_Mayers')
# The correction takes a long time. Create a backup copy incase irreversible changes are made so we don't need to re compute everything
CloneWorkspace(InputWorkspace='POL95598_Mayers', OutputWorkspace='POL95598_MayersCopy')

# Group workspaces and put to dSpacing + focussing
GroupWorkspaces(InputWorkspaces='POL95598, POL95598_Mayers, POL95598_MSCA', OutputWorkspace='POL')
wsgroup = mtd['POL']
wsgroup_names = wsgroup.getNames()

# Seems to introduce overall scale factor. Multiply by ~ 10 to get data all on same scale
Scale(InputWorkspace='POL95598_Mayers',OutputWorkspace='POL95598_Mayers',Factor=10)

for ws in wsgroup_names:
        loop_ws = ConvertUnits(InputWorkspace=ws, OutputWorkspace=ws, Target='dSpacing')
        DiffractionFocussing(InputWorkspace=loop_ws, OutputWorkspace=loop_ws, GroupingFileName=grouping_file_path)

Mayers_MSCA = Divide(LHSWorkspace='POL95598_MSCA', RHSWorkspace='POL95598_Mayers')
plot(Mayers_MSCA, 3)