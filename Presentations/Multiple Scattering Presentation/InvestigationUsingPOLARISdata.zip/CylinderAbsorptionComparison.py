# USER SETUP - Note this script takes 5-15 minutes for multiple scattering corrections
cylinder_radius = 0.4 # Radius is in cm
cylinder_height = 4.0 # Height is in cm
cylinder_position = [0., 0., 0.]
geometry_json = {'Shape': 'Cylinder', 'Height': cylinder_height, 'Radius': cylinder_radius, 'Center': cylinder_position}
material_json = {'ChemicalFormula': 'V'}

# Essential files required : - 
# Offset file:
cal_file_path = r"C:\Users\ezz64382\Desktop\MultipleScattering\InvestigationUsingPOLARISdata\cycle_16_3_silicon_all_spectra.cal"
# Grouping file:
grouping_file_path = r"C:\Users\ezz64382\Desktop\MultipleScattering\InvestigationUsingPOLARISdata\Master_copy_of_grouping_file_with_essential_masks.cal"
#----------------------------------------------------------------------------------------------------------------------#

# Load vanadium and set the sample
Load(Filename= 'POL95598.nxs', OutputWorkspace='POL95598')
NormaliseByCurrent(InputWorkspace='POL95598', OutputWorkspace='POL95598')
SetSample(InputWorkspace='POL95598', Geometry=geometry_json, Material=material_json)
# Load background count
Load(Filename='POL95597.nxs', OutputWorkspace='POL95597')
NormaliseByCurrent(InputWorkspace='POL95597', OutputWorkspace='POL95597')
# subtract the background from the vanadium
Minus(LHSWorkspace='POL95598', RHSWorkspace='POL95597', OutputWorkspace='POL95598')
DeleteWorkspace('POL95597')
# get rid of 'negative' counts at very low TOF
CropWorkspace(InputWorkspace='POL95598', OutputWorkspace='POL95598', XMin=750, XMax=20000)
AlignDetectors(InputWorkspace='POL95598', OutputWorkspace='POL95598', CalibrationFile=cal_file_path)
# the first 55 detectors are unused detectors or monitors on Polaris
MaskDetectors(Workspace='POL95598', SpectraList='1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55')

# Create workspaces in the correct units
ConvertUnits(InputWorkspace="POL95598", OutputWorkspace="POL95598_MSCA", Target='Wavelength')
CloneWorkspace(InputWorkspace="POL95598_MSCA", OutputWorkspace="POL95598_CA")
ConvertUnits(InputWorkspace="POL95598", OutputWorkspace="POL95598_Mayers", Target='TOF')

#Added flag to MultipleScatteringCylinderAbsorption to disable multiple scattering corrections
MultipleScatteringCylinderAbsorption(InputWorkspace="POL95598_MSCA", OutputWorkspace="POL95598_MSCA", CylinderSampleRadius=cylinder_height, MultipleScattering=False)

# CylinderAbsorption corrections
ca_ws_abs_factors = CylinderAbsorption(InputWorkspace="POL95598_CA", CylinderSampleHeight=mayers_cylinder_height, CylinderSampleRadius=cylinder_radius)
POL95598_CA = Divide(LHSWorkspace="POL95598_CA", RHSWorkspace=ca_ws_abs_factors)

#Mayer's correction
MayersSampleCorrection(InputWorkspace="POL95598_Mayers", MultipleScattering=False, OutputWorkspace="POL95598_Mayers")

# to dSpacing + focussing
for ws in ["POL95598","POL95598_MSCA", "POL95598_Mayers", "POL95598_CA"]:
    loop_ws = ConvertUnits(InputWorkspace=ws, OutputWorkspace=ws, Target='dSpacing')
    DiffractionFocussing(InputWorkspace=loop_ws, OutputWorkspace=loop_ws, GroupingFileName=grouping_file_path)

division_list = []
division_list.append(mtd['POL95598_Mayers']/mtd['POL95598_CA'])
division_list.append(mtd['POL95598_MSCA']/mtd['POL95598_CA'])

plot(division_list, 3)