# USER SETUP
# Radius is in cm
cylinder_radius = 0.1
# Details for MayersSampleCorrection
cylinder_height = 1.5
cylinder_position = [0., 0., 0.]
#Set sample geometry
geometry_json = {'Shape': 'Cylinder', 'Height': cylinder_height, 'Radius': cylinder_radius, 'Center': cylinder_position}
material_json = {'ChemicalFormula': 'V'}
# Set folder path:
folder_name = "Vanadium"
folder_path = r"C:\Users\ezz64382\Desktop\McStas\\" + folder_name + "\\"
#----------------------------------------------------------------------------------------------------------------------#

# Load McStas data
LoadMcStas(Filename=folder_path + r"\output\mccode.h5", OutputWorkspace='McStas')
RenameWorkspace(InputWorkspace='EventWS_all_list_p_x_y_n_id_t', OutputWorkspace='All')
RenameWorkspace(InputWorkspace='EventWS_multi_list_p_x_y_n_id_t', OutputWorkspace='Multiple')
RenameWorkspace(InputWorkspace='EventWS_single_list_p_x_y_n_id_t', OutputWorkspace='Single')

SetSample(InputWorkspace='All', Geometry=geometry_json, Material=material_json)
SetSample(InputWorkspace='Multiple', Geometry=geometry_json, Material=material_json)
SetSample(InputWorkspace='Single', Geometry=geometry_json, Material=material_json)

#Rebin(InputWorkspace='All', Params=500, OutputWorkspace='All')
#Rebin(InputWorkspace='Single', Params=500, OutputWorkspace='Single')

# Absorption correction on Single to get our idealised workspace (for some reason this crashes the debug, use Mayers instead)
#ConvertUnits(InputWorkspace='Single', Target='Wavelength', OutputWorkspace='Ideal')
#CylinderAbsorption(InputWorkspace='Ideal', CylinderSampleHeight=cylinder_height, CylinderSampleRadius=cylinder_radius, OutputWorkspace='caIdeal')
#Divide(LHSWorkspace ='Ideal', RHSWorkspace='caIdeal', OutputWorkspace='Ideal')
MayersSampleCorrection(InputWorkspace='Single', MultipleScattering=False, OutputWorkspace='Ideal')

# MSCA
ConvertUnits(InputWorkspace='All', Target='Wavelength', OutputWorkspace='MSCA')
MultipleScatteringCylinderAbsorption(InputWorkspace='MSCA', OutputWorkspace='MSCA', CylinderSampleRadius=cylinder_radius)

# Apply Mayers correction (takes about half an hour in debug mode)
#MayersSampleCorrection(InputWorkspace='All', MultipleScattering=True, OutputWorkspace='Mayers')

# Plot the two workspaces alongside the ideal one
ConvertUnits(InputWorkspace='Ideal', Target='Wavelength', OutputWorkspace='Ideal')
GroupWorkspaces(InputWorkspaces='Ideal,MSCA', OutputWorkspace='No Abs/Multi Scatt')

# Divide the correct results by the actual result to see if we get a horizontal straight line plot
MSCA_All = Divide('MSCA','All', WarnOnZeroDivide=False)
Scale(InputWorkspace='MSCA_All', Factor=1./1.171, OutputWorkspace='MSCA_All')
SumSpectra(InputWorkspace='MSCA_All', OutputWorkspace='Sum')
