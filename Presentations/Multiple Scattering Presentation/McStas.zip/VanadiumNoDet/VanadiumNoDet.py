# USER SETUP
# Radius is in cm
cylinder_radius = 0.1
# Details of cylinder geometry
cylinder_height = 1.5
cylinder_position = [0., 0., 0.]
geometry_json = {'Shape': 'Cylinder', 'Height': cylinder_height, 'Radius': cylinder_radius, 'Center': cylinder_position}
material_json = {'ChemicalFormula': 'V'}
# Set folder path:
folder_name = "VanadiumNoDet"
folder_path = r"C:\Users\ezz64382\Desktop\McStas\\" + folder_name + "\\"
#----------------------------------------------------------------------------------------------------------------------#

# Load McStas data
LoadMcStas(Filename=folder_path + r"\output\mccode.h5", OutputWorkspace='McStas')
# Scale data from seconds to microseconds
ScaleX(InputWorkspace='McStas',Factor=1e6, OutputWorkspace='McStas')
# Manually set instrument to McStas generated IDF file
LoadInstrument(Workspace='McStas', Filename=folder_path + folder_name + '.instr.xml', RewriteSpectraMap=True)
# Rename workspaces for ease
RenameWorkspace(InputWorkspace='all.t_I_McStas', OutputWorkspace='All')
RenameWorkspace(InputWorkspace='multi.t_I_McStas', OutputWorkspace='Multiple')
RenameWorkspace(InputWorkspace='single.t_I_McStas', OutputWorkspace='Single')

# Manually put units in time of flight
wsgroup = mtd['McStas']
wsgroup_names = wsgroup.getNames()
for wsname in wsgroup_names:
    ws = mtd[wsname]
    # Set sample for each workspace
    SetSample(InputWorkspace=ws, Geometry=geometry_json, Material=material_json)
    ws.getAxis(0).setUnit('TOF')

# Cylinder absorption correction on Single without multiple scattering to get our idealised workspace
ConvertUnits(InputWorkspace='Single', Target='Wavelength', OutputWorkspace='Ideal')
CylinderAbsorption(InputWorkspace='Ideal', CylinderSampleHeight=cylinder_height, CylinderSampleRadius=cylinder_radius, OutputWorkspace='attfac')
Divide(LHSWorkspace='Ideal', RHSWorkspace='attfac', OutputWorkspace='Ideal')
DeleteWorkspace('attfac')

# MSCA
ConvertUnits(InputWorkspace='All', Target='Wavelength', OutputWorkspace='MSCA')
MultipleScatteringCylinderAbsorption(InputWorkspace='MSCA', OutputWorkspace='MSCA', CylinderSampleRadius=cylinder_radius)

# Apply Mayers correction and put in units of Wavelength for comparison
MayersSampleCorrection(InputWorkspace='All', MultipleScattering=True, OutputWorkspace='Mayers')
ConvertUnits(InputWorkspace='Mayers', Target='Wavelength', OutputWorkspace='Mayers')
# There seems to be a scaling factor of 3 coming from somewhere
Scale(InputWorkspace='Mayers', Factor=0.333, OutputWorkspace='Mayers')

# Plot the two workspaces alongside the ideal one
GroupWorkspaces(InputWorkspaces='Ideal,MSCA,Mayers', OutputWorkspace='No Abs/Multi Scatt')
ConvertUnits(InputWorkspace='All', Target='Wavelength', OutputWorkspace='AllWL')
plot('No Abs/Multi Scatt',0)

# Divide the correct results by the actual result to see if we get a horizontal straight line plot
MSCA_Ideal = Divide('MSCA','Ideal')
Mayers_Ideal = Divide('Mayers','Ideal')
MSCA_All = Divide('MSCA','AllWL')
Mayers_All = Divide('Mayers','AllWL')

GroupWorkspaces(InputWorkspaces='MSCA_Ideal,Mayers_Ideal,MSCA_All,Mayers_All', OutputWorkspace='Ratios')
plot('Ratios',0)
