Tasks:
  Preparation:
    1. You need `mantid` to be accessible in the environment
      - Easiest for Windows is to use the `command-prompt.bat` in a `build/bin/Debug` (or Release)
      - Easiest for Linux is to use Windows
  Part 1:
    1. Make model.py conform to the Model part of MVP
    1. Make it work when I click `Convert`
    1. Make it work when I type an input number and press `Enter` (both big enter [Return] and numpad enter [Enter])
