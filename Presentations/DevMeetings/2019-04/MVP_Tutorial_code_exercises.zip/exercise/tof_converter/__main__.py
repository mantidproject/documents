from presenter import TofConverterPresenter
from qtpy.QtWidgets import QApplication

app = QApplication(['MVP Tutorial'])

pres = TofConverterPresenter()
app.exec_()
